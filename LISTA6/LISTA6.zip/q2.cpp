# include <cstdio>

class Posicao{
    public:
        int l, c;
};

class FilaPosicao{
    public:
        Posicao* v;
        int tam_max;
        int inicio;
        int fim;
        int count;

        FilaPosicao(int tamanho){//método construtor, inicializa a fila
            v = new Posicao[tamanho];// cria vetor de inteiros com o tamanho desejado
            tam_max = tamanho;
            inicio = 0;
            fim = -1;
            count = 0;
        }

        void enfileirar(Posicao p){//método enfileirar
            if(count < tam_max){
                fim = (fim+1)%tam_max;
                count++;
                v[fim] = p;
            }
        }

        Posicao desenfileirar(){//método desenfileirar
            if(count >= 0){
                inicio = (inicio+1)%tam_max;
                count--;
                return v[inicio];
            }
            throw "Impossivel retirar da fila vazia";
        }

        int vazia(){//método fila vazia
            return count == 0;
        }
};

int main (){
    
    Posicao p;
    FilaPosicao f(10); // cria fila de tamanho 10

    for(int i = 0; i < 10; i++){
        p.l = i*i;
        p.c = i*i*i;
        f.enfileirar(p);
    }

    for(int i = 0; i < 5; i++){
        p = f.desenfileirar();
        printf ("linha %d. coluna %d\n", p.l, p.c);
    }
    
    printf ("\n");
    
    for(int i = 0; i < 5; i++){
        p.l = i*i;
        p.c = i*i*i;
        f.enfileirar(p);
    }

    while (!f.vazia()){
        p = f.desenfileirar();
        printf ("linha %d, coluna %d\n", p.l, p.c);
    }
}