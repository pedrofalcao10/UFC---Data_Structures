#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cmath>

using namespace std;

class NoRegistro{
    public:
        int chave;
        NoRegistro *prox = NULL;
};

class TabelaDispersao_EE_Divisao{
    public :
        NoRegistro **tabela;
        int m; //tamanho da tabela
        int cont; //número de elementos na tabela
        
        TabelaDispersao_EE_Divisao(int tamanho){ //método construtor, inicializa a tabela
            m = tamanho ;
            tabela = new NoRegistro *[m];
            cont = 0;
        }

        int metodo_divisao(int chave, int m){
            return chave%m;
        }
        
        int inserir(NoRegistro * reg){ //método inserir
            int pos = metodo_divisao(reg->chave, m);

            if(tabela[pos] == NULL){
                tabela[pos] = reg;
            }
            else{
                reg->prox = tabela[pos];
                tabela[pos] = reg;
            }
        }
        
        // método buscar
        NoRegistro *buscar(int chave){
            int pos = metodo_divisao(chave, m);

            NoRegistro* aux = tabela[pos];

            while(aux != NULL){
                if(aux->chave == chave){
                    return aux;
                }
                aux = aux->prox;
            }
        }
        
        NoRegistro * remover(int chave){ //método remover, devolve um ponteiro para o nó removido
            int pos = metodo_divisao(chave, m); //não libera o espaço do nó

            if(tabela[pos] == NULL){
                return NULL;
            }
            else{
                if(tabela[pos]->chave == chave){
                    NoRegistro* h = tabela[pos];
                    tabela[pos] = tabela[pos]->prox;
                    
                    return h;
                }
                else{
                    NoRegistro* aux = tabela[pos];
                    
                    while(aux->prox != NULL){
                        if(aux->prox->chave == chave){
                            NoRegistro* h = aux->prox;
                            aux->prox = aux->prox->prox;
                            
                            return h;
                            
                            break;
                        }

                        aux = aux->prox;
                    }
                }
            }
        }
        
        void eliminar (int chave){ // método eliminar, remove o nó liberando o espaço
            delete(remover(chave));
        }
};

class TabelaDispersao_EE_Multiplicacao{
    public:
        NoRegistro **tabela;
        int m; //tamanho da tabela
        int cont; //número de elementos na tabela
        
        TabelaDispersao_EE_Multiplicacao (int tamanho){ // método construtor, inicializa a tabela
            m = tamanho;
            tabela = new NoRegistro *[m];
            cont = 0;
        }

        int metodo_multiplicacao (int chave, int m){
            float a = 0.6180339;
            float y;
            double p_i;

            y = modf(chave*a, &p_i);

            modf(y*m, &p_i);

            return p_i;
        }
        
        int inserir (NoRegistro * reg){ //método inserir
            int pos = metodo_multiplicacao(reg->chave, m);

            if(tabela[pos] == NULL){
                tabela[pos] = reg;
            }
            else{
                reg->prox = tabela[pos];
                tabela[pos] = reg;
            }
        }
        
        NoRegistro * buscar (int chave){// método buscar
            int pos = metodo_multiplicacao(chave, m);

            NoRegistro* aux = tabela[pos];

            while(aux != NULL){
                if(aux->chave == chave){
                    return aux;
                }

                aux = aux->prox;
            }
        }
        
        NoRegistro * remover (int chave){// método remover, devolve um ponteiro para o nó removido
            // não libera o espaço do nó
            
            int pos = metodo_multiplicacao(chave, m);

            if(tabela[pos] == NULL){
                return NULL;
            }
            else{
                if(tabela[pos]->chave == chave){
                    NoRegistro* h = tabela[pos];
                    tabela[pos] = tabela[pos]->prox;
                    
                    return h;
                }
                else{
                    NoRegistro* aux = tabela[pos];
                    
                    while(aux->prox != NULL){
                        if(aux->prox->chave == chave){
                            NoRegistro* h = aux->prox;
                            aux->prox = aux->prox->prox;
                            
                            return h;
                            
                            break;
                        }

                        aux = aux->prox;
                    }
                }
            }
        }
        
        void eliminar (int chave){// método eliminar, remove o nó liberando o espaço
            delete(remover(chave));
        }
};

class Registro{
    public:
        int chave;
        int dado;
        Registro *prox = NULL;
};

class ListaOrdenada{
    public:
        Registro **L; // vetor de ponteiros de registros
        int tam_max; // tamanho máximo da lista
        int count; //número de elementos na lista
        
        ListaOrdenada (int tamanho){//método construtor, inicializa a lista
            tam_max = tamanho ;
            L = new Registro *[tam_max]();
            count = 0;
        }

        void swap(Registro *a, Registro *b){
            Registro aux = *a;
            *a = *b;
            *b = aux;
        }

        int busca_inserir(int valor){
            int ini = 0, fim = count-1, meio;

            while(ini <= fim){
                int meio = (ini + fim)/2;

                if(L[meio]->chave == valor){
                    return meio;
                }
                else{
                    if(L[meio]->chave < valor){
                        ini = meio + 1;
                    }
                    else{
                        fim = meio - 1;
                    }
                }
            }
            return fim + 1;
        }

        int inserir(Registro *reg){//método inserir, retorna a posição do registro inserido no vetor
            if(count == 0){
                L[count++] = reg;
                return 0;
            }

            int p = busca_inserir(reg->chave);
            
            L[count++] = reg;

            for(int i = count-1; i > p; i--){
                swap(L[i], L[i-1]);
            }

            return p;
        }
        
        Registro* buscar(int valor){ // método buscar, implementa busca binária
            int ini = 0, fim = count-1, meio;
            
            while(ini <= fim){
                meio = (ini + fim)/2;

                if(L[meio]->chave == valor){
                    return L[meio];
                }
                else{
                    if(L[meio]->chave < valor){
                        ini = meio + 1;
                    }
                    else{
                        fim = meio - 1;
                    }
                }
            }
            return nullptr;
        }

        Registro* remover(int valor){//método remover, retira da lista e devolve ponteiro para o registro removido
            int ini = 0, fim = count-1, meio;

            while(ini <= fim){
                meio = (ini + fim)/2;

                if(L[meio]->chave < valor){
                    ini = meio + 1;
                }
                else if(L[meio]->chave > valor){
                    fim = meio - 1;
                }
                else{
                    for(int i = meio; i < count-1; i++){
                        swap(L[i], L[i+1]);
                    }
                    return L[count--];
                }
            }
            return nullptr;
        }
};

int testeInsercao_TDEED(int m, int n, NoRegistro *Regs){ //realiza n inserções em uma tabela de tamanho m e retorna o tempo decorrrido
    // os registros que serão inseridos estão no vetor Regs
    
    TabelaDispersao_EE_Divisao TDEED (m); // cria tabela
    
    int inicio , fim; // registra inicio das inser ções
    
    inicio = clock(); // registra início do procedimento de inser ção
    
    for ( int i = 0; i < n; i ++){// insere os nós na tabela
        TDEED.inserir (& Regs [i]);
    }
    
    fim = clock();// registra o final das inser ções

    return fim-inicio;
}

int testeInsercao_TDEEM(int m, int n, NoRegistro *Regs){ //realiza 'n' inserções em uma tabela de tamanho 'm' e retorna o tempo decorrrido
    // os registros que serão inseridos estão no vetor Regs
    
    TabelaDispersao_EE_Multiplicacao TDEEM (m); // cria tabela
    
    int inicio, fim; // registra inicio das inser ções
    
    inicio = clock(); // registra início do procedimento de inser ção
    
    for (int i = 0; i < n; i++){// insere os nós na tabela
        TDEEM.inserir(& Regs [i]);
    }
    
    fim = clock ();// registra o final das inserções

    return fim-inicio;
}

int testeInsercao_LISTA(int p, Registro Reg){ //realiza 'n' inserções em uma tabela de tamanho 'm' e retorna o tempo decorrrido
    // os registros que serão inseridos estão no vetor Regs
    
    ListaOrdenada list (p); // cria tabela
    
    int inicio, fim; // registra inicio das inser ções
    
    inicio = clock(); // registra início do procedimento de inser ção
    
    for (int i = 0; i < p; i++){// insere os nós na tabela
        list.inserir(& Reg);
    }
    
    fim = clock ();// registra o final das inserções

    return fim-inicio;
}

void inicializa_Chaves_Aleatorias_TD(int n, NoRegistro *Regs){ //inicializa os registros com chaves aleatórias não repetidas
    srand (time (0));

    for (int i = 0; i < n; i ++){
        Regs [i].chave = rand ();
    }
}

void inicializa_Chaves_Aleatorias_LISTA(int n, Registro *Reg){ //inicializa os registros com chaves aleatórias não repetidas
    srand (time (0));

    for (int i = 0; i < n; i ++){
        Reg [i].chave = rand ();
    }
}

int main (){

    int m; //tamanho da tabela de dispersão e divisão
    int n; //número de registros a serem inseridos
    cout << " Tamanho da tabela e numero de regs a inserir (m e n):";
    cin >> m >> n;

    NoRegistro *Regs1 = new NoRegistro [n];// cria registros a serem inseridos nas respectivas estruturas

    inicializa_Chaves_Aleatorias_TD (n, Regs1);//inicializa chaves aleatórias

    int duracaoTDEED = testeInsercao_TDEED (m, n, Regs1);//testa tabela de dispersão com encadeamento externo e mé todo da divis ão

    cout << " Duracao do teste de insercao\n";
    cout << " Tamanho da tabela: " << m << "\n";
    cout << " Numero de registros: " << n << "\n";
    cout << " Duracao da insercao: " << (float) 1000*duracaoTDEED/CLOCKS_PER_SEC << "ms\n";

    

    cout << endl << endl << endl;
    
    

    int p; //tamanho da tabela de dispersão e multiplicação
    int q; //número de registros a serem inseridos
    cout << " Tamanho da tabela e numero de regs a inserir (m e n):";
    cin >> p >> q;

    NoRegistro *Regs2 = new NoRegistro [q];// cria registros a serem inseridos nas respectivas estruturas

    inicializa_Chaves_Aleatorias_TD (q, Regs2);//inicializa chaves aleatórias

    int duracaoTDEEM = testeInsercao_TDEEM (p, q, Regs2);//testa tabela de dispersão com encadeamento externo e mé todo da divis ão

    cout << " Duracao do teste de insercao da tabela: \n";
    cout << " Tamanho da tabela: " << p << "\n";
    cout << " Numero de registros: " << q << "\n";
    cout << " Duracao da insercao: " << (float) 1000*duracaoTDEEM/CLOCKS_PER_SEC << "ms\n";


    
    cout << endl << endl << endl;
    

    
    int r; // tamanho da lista ordenada
    cout << " Tamanho da lista ordenada: ";
    cin >> r;
    
    Registro *Reg = new Registro [r];// cria registros a serem inseridos nas respectivas estruturas

    inicializa_Chaves_Aleatorias_LISTA (r, Reg);//inicializa chaves aleatórias

    int duracaoLISTA = testeInsercao_LISTA (r, *Reg);//testa tabela de dispersão com encadeamento externo e mé todo da divis ão

    cout << " Duracao do teste de insercao da lista: \n";
    cout << " Tamanho da lista: " << r << "\n";
    cout << " Duracao da insercao: " << (float) 1000*duracaoLISTA/CLOCKS_PER_SEC << "ms\n";
}